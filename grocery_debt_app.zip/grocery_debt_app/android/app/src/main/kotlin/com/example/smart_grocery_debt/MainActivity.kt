package com.example.smart_grocery_debt

import android.Manifest
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telephony.SmsManager
import android.telephony.SubscriptionManager
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/**
 * SMS is sent from the default SMS subscription, NEVER an arbitrary SIM.
 * Android SEND_SMS is sensitive/hard-restricted and is not normally approved
 * for a grocery bookkeeping app in Google Play. See project README.
 */
class MainActivity : FlutterActivity() {
    private companion object {
        const val CHANNEL = "smart_grocery_debt/sms"
        const val SMS_PERMISSION_REQUEST = 8142
        const val SEND_TIMEOUT_MS = 90_000L
    }

    private data class PendingSms(
        val phone: String,
        val message: String,
        val result: MethodChannel.Result,
    )

    private var waitingForPermission: PendingSms? = null
    private var pendingSendResult: MethodChannel.Result? = null
    private var sentReceiver: BroadcastReceiver? = null
    private var sendTimeout: Runnable? = null
    private val handler = Handler(Looper.getMainLooper())

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "sendSms" -> onSendSms(call, result)
                    else -> result.notImplemented()
                }
            }
    }

    private fun onSendSms(call: MethodCall, result: MethodChannel.Result) {
        if (waitingForPermission != null || pendingSendResult != null) {
            result.error("SMS_BUSY", "هناك رسالة أخرى قيد الإرسال.", null)
            return
        }
        val phone = call.argument<String>("phone")
        val message = call.argument<String>("message")
        if (phone == null || !Regex("^\\+9677[0-9]{8}$").matches(phone)) {
            result.error("INVALID_PHONE", "رقم الهاتف اليمني غير صالح.", null)
            return
        }
        if (message.isNullOrBlank() || message.length > 700) {
            result.error("INVALID_TEXT", "نص الرسالة مطلوب وأقصاه 700 حرف.", null)
            return
        }
        if (!packageManager.hasSystemFeature(PackageManager.FEATURE_TELEPHONY_MESSAGING)) {
            result.error("NO_SMS_HARDWARE", "الجهاز لا يدعم إرسال SMS.", null)
            return
        }

        if (checkSelfPermission(Manifest.permission.SEND_SMS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            waitingForPermission = PendingSms(phone, message, result)
            requestPermissions(arrayOf(Manifest.permission.SEND_SMS), SMS_PERMISSION_REQUEST)
            return
        }
        sendUsingDefaultSim(phone, message, result)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray,
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != SMS_PERMISSION_REQUEST) return
        val request = waitingForPermission ?: return
        waitingForPermission = null
        if (grantResults.isEmpty() || grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            request.result.error(
                "SMS_PERMISSION_DENIED",
                "لم يمنح نظام أندرويد صلاحية إرسال SMS.",
                null,
            )
        } else {
            sendUsingDefaultSim(request.phone, request.message, request.result)
        }
    }

    private fun sendUsingDefaultSim(
        phone: String,
        message: String,
        result: MethodChannel.Result,
    ) {
        try {
            // If there are 2 SIMs and no default SMS SIM, abort rather than
            // accidentally charging a different SIM.
            val subscriptionId = SmsManager.getDefaultSmsSubscriptionId()
            if (subscriptionId == SubscriptionManager.INVALID_SUBSCRIPTION_ID) {
                result.error(
                    "NO_DEFAULT_SMS_SIM",
                    "حدّد شريحة SMS الافتراضية من إعدادات أندرويد أولاً.",
                    null,
                )
                return
            }
            val smsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                getSystemService(SmsManager::class.java)
                    .createForSubscriptionId(subscriptionId)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getSmsManagerForSubscriptionId(subscriptionId)
            }
            val parts = smsManager.divideMessage(message)
            if (parts.isEmpty() || parts.size > 10) {
                result.error("SMS_TOO_LONG", "عدد أجزاء الرسالة غير مقبول.", null)
                return
            }

            val action = "$packageName.SMS_SENT_${System.nanoTime()}"
            val intentFilter = IntentFilter(action)
            var receivedParts = 0
            var firstFailure: Int? = null
            var completed = false
            pendingSendResult = result

            fun finish(error: String?) {
                if (completed) return
                completed = true
                sendTimeout?.let { handler.removeCallbacks(it) }
                sendTimeout = null
                sentReceiver?.let { receiver ->
                    try { unregisterReceiver(receiver) } catch (_: IllegalArgumentException) { }
                }
                sentReceiver = null
                pendingSendResult = null
                if (error == null) {
                    result.success(
                        mapOf(
                            "submitted" to true,
                            "parts" to parts.size,
                            "subscriptionId" to subscriptionId,
                        ),
                    )
                } else {
                    result.error("SMS_NOT_SUBMITTED", error, null)
                }
            }

            val receiver = object : BroadcastReceiver() {
                override fun onReceive(context: Context?, intent: Intent?) {
                    receivedParts++
                    if (resultCode != Activity.RESULT_OK && firstFailure == null) {
                        firstFailure = resultCode
                    }
                    if (receivedParts >= parts.size) {
                        val failure = firstFailure
                        finish(if (failure == null) null else "فشل إرسال SMS؛ رمز أندرويد: $failure")
                    }
                }
            }
            sentReceiver = receiver
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                registerReceiver(receiver, intentFilter, Context.RECEIVER_NOT_EXPORTED)
            } else {
                @Suppress("DEPRECATION")
                registerReceiver(receiver, intentFilter)
            }

            val sentIntents = ArrayList<PendingIntent>(parts.size)
            for (index in parts.indices) {
                val sentIntent = Intent(action).setPackage(packageName)
                    .putExtra("part_index", index)
                val pending = PendingIntent.getBroadcast(
                    this,
                    index,
                    sentIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
                )
                sentIntents.add(pending)
            }

            val timeout = Runnable { finish("انتهت مهلة تأكيد الإرسال من أندرويد.") }
            sendTimeout = timeout
            handler.postDelayed(timeout, SEND_TIMEOUT_MS)
            smsManager.sendMultipartTextMessage(phone, null, parts, sentIntents, null)
        } catch (error: Exception) {
            // Includes hard-restricted permission, carrier limits, etc.
            val receiver = sentReceiver
            if (receiver != null) {
                try { unregisterReceiver(receiver) } catch (_: IllegalArgumentException) { }
            }
            sentReceiver = null
            sendTimeout?.let { handler.removeCallbacks(it) }
            sendTimeout = null
            val response = pendingSendResult
            pendingSendResult = null
            (response ?: result).error(
                "SMS_ERROR", error.localizedMessage ?: "تعذّر إرسال SMS.", null,
            )
        }
    }

    override fun onDestroy() {
        waitingForPermission?.result?.error("ACTIVITY_CLOSED", "أُغلقت الواجهة.", null)
        waitingForPermission = null
        pendingSendResult?.error("ACTIVITY_CLOSED", "أُغلقت الواجهة.", null)
        pendingSendResult = null
        sentReceiver?.let { receiver ->
            try { unregisterReceiver(receiver) } catch (_: IllegalArgumentException) { }
        }
        sentReceiver = null
        sendTimeout?.let { handler.removeCallbacks(it) }
        sendTimeout = null
        super.onDestroy()
    }
}
