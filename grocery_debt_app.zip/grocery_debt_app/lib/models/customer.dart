class Customer {
  final int? id;
  final String name;
  final String phone;

  /// The maximum debt in the app's configured smallest money unit.
  final int creditLimit;

  /// The outstanding debt, calculated only from saved transactions.
  final int currentBalance;

  const Customer({
    this.id,
    required this.name,
    required this.phone,
    required this.creditLimit,
    this.currentBalance = 0,
  });

  factory Customer.fromMap(Map<String, Object?> map) {
    return Customer(
      id: map['id'] as int,
      name: map['name'] as String,
      phone: map['phone'] as String,
      creditLimit: map['credit_limit'] as int,
      currentBalance: map['current_balance'] as int,
    );
  }

  Map<String, Object?> toMap() {
    return <String, Object?>{
      if (id != null) 'id': id,
      'name': name,
      'phone': phone,
      'credit_limit': creditLimit,
      'current_balance': currentBalance,
    };
  }

  Customer copyWith({
    int? id,
    String? name,
    String? phone,
    int? creditLimit,
    int? currentBalance,
  }) {
    return Customer(
      id: id ?? this.id,
      name: name ?? this.name,
      phone: phone ?? this.phone,
      creditLimit: creditLimit ?? this.creditLimit,
      currentBalance: currentBalance ?? this.currentBalance,
    );
  }

  @override
  String toString() {
    return 'Customer(id: $id, name: $name, phone: $phone, '
        'creditLimit: $creditLimit, currentBalance: $currentBalance)';
  }
}
