import 'dart:convert';

import 'package:crypto/crypto.dart';

enum DebtTransactionType {
  debt('debt'),
  payment('payment');

  const DebtTransactionType(this.databaseValue);

  final String databaseValue;

  String get arabicLabel => switch (this) {
        DebtTransactionType.debt => 'دين',
        DebtTransactionType.payment => 'سداد',
      };

  static DebtTransactionType fromDatabaseValue(String value) {
    for (final type in DebtTransactionType.values) {
      if (type.databaseValue == value) return type;
    }
    throw FormatException('نوع المعاملة غير معروف: $value');
  }
}

class DebtTransaction {
  static const String genesisHash = 'GENESIS';

  final int? id;
  final int customerId;
  final DebtTransactionType type;

  /// A positive amount in the app's configured smallest money unit.
  final int amount;

  /// Purchased items description. Empty for payment transactions.
  final String purchases;

  /// UTC timestamp. The app displays it in the user's local time zone.
  final DateTime createdAt;

  /// Hash of the preceding transaction for the same customer.
  final String previousHash;

  /// SHA-256 digest of all fields above, including previousHash.
  final String recordHash;

  const DebtTransaction({
    required this.id,
    required this.customerId,
    required this.type,
    required this.amount,
    required this.purchases,
    required this.createdAt,
    required this.previousHash,
    required this.recordHash,
  });

  factory DebtTransaction.create({
    required int id,
    required int customerId,
    required DebtTransactionType type,
    required int amount,
    required String purchases,
    required DateTime createdAt,
    required String previousHash,
  }) {
    final dateUtc = createdAt.toUtc();
    final hash = calculateHash(
      id: id,
      customerId: customerId,
      type: type,
      amount: amount,
      purchases: purchases,
      createdAt: dateUtc,
      previousHash: previousHash,
    );

    return DebtTransaction(
      id: id,
      customerId: customerId,
      type: type,
      amount: amount,
      purchases: purchases,
      createdAt: dateUtc,
      previousHash: previousHash,
      recordHash: hash,
    );
  }

  factory DebtTransaction.fromMap(Map<String, Object?> map) {
    return DebtTransaction(
      id: map['id'] as int,
      customerId: map['customer_id'] as int,
      type: DebtTransactionType.fromDatabaseValue(map['type'] as String),
      amount: map['amount'] as int,
      purchases: map['purchases'] as String,
      createdAt: DateTime.parse(map['created_at'] as String).toUtc(),
      previousHash: map['previous_hash'] as String,
      recordHash: map['record_hash'] as String,
    );
  }

  Map<String, Object?> toMap() {
    return <String, Object?>{
      if (id != null) 'id': id,
      'customer_id': customerId,
      'type': type.databaseValue,
      'amount': amount,
      'purchases': purchases,
      'created_at': createdAt.toUtc().toIso8601String(),
      'previous_hash': previousHash,
      'record_hash': recordHash,
    };
  }

  static String calculateHash({
    required int id,
    required int customerId,
    required DebtTransactionType type,
    required int amount,
    required String purchases,
    required DateTime createdAt,
    required String previousHash,
  }) {
    // A fixed ordered JSON array makes serialization deterministic.
    final canonicalRecord = jsonEncode(<Object>[
      'smart_grocery_debt_transaction_v1',
      id,
      customerId,
      type.databaseValue,
      amount,
      purchases,
      createdAt.toUtc().toIso8601String(),
      previousHash,
    ]);
    return sha256.convert(utf8.encode(canonicalRecord)).toString();
  }

  bool get hasValidHash {
    final transactionId = id;
    if (transactionId == null) return false;
    final expected = calculateHash(
      id: transactionId,
      customerId: customerId,
      type: type,
      amount: amount,
      purchases: purchases,
      createdAt: createdAt,
      previousHash: previousHash,
    );
    return expected == recordHash;
  }

  @override
  String toString() {
    return 'DebtTransaction(id: $id, customerId: $customerId, '
        'type: ${type.databaseValue}, amount: $amount, '
        'purchases: $purchases, createdAt: $createdAt, '
        'previousHash: $previousHash, recordHash: $recordHash)';
  }
}
