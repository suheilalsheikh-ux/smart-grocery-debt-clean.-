import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/customer.dart';
import '../services/database_helper.dart';
import '../utils/money_format.dart';

class AddCustomerDialog extends StatefulWidget {
  const AddCustomerDialog({super.key, this.database});
  final DatabaseHelper? database;

  @override
  State<AddCustomerDialog> createState() => _AddCustomerDialogState();
}

class _AddCustomerDialogState extends State<AddCustomerDialog> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _creditLimit = TextEditingController();
  bool _busy = false;
  String? _failure;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _creditLimit.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (_busy || !_formKey.currentState!.validate()) return;
    setState(() {
      _busy = true;
      _failure = null;
    });
    try {
      final created = await (widget.database ?? DatabaseHelper.instance).createCustomer(
        Customer(
          name: _name.text.trim(),
          phone: _phone.text.trim(),
          creditLimit: MoneyFormat.parseWholeRiyals(_creditLimit.text)!,
        ),
      );
      if (mounted) Navigator.of(context).pop(created);
    } catch (error) {
      if (!mounted) return;
      setState(() => _failure = 'تعذر حفظ الزبون. تحقق من البيانات.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('إضافة زبون جديد'),
      content: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 430),
        child: SingleChildScrollView(
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextFormField(
                  controller: _name,
                  autofocus: true,
                  textInputAction: TextInputAction.next,
                  decoration: const InputDecoration(labelText: 'اسم الزبون',
                    prefixIcon: Icon(Icons.person_outline)),
                  validator: (value) => (value ?? '').trim().isEmpty
                      ? 'أدخل اسم الزبون' : null,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _phone,
                  keyboardType: TextInputType.phone,
                  textDirection: TextDirection.ltr,
                  maxLength: 18,
                  decoration: const InputDecoration(labelText: 'رقم الهاتف',
                    prefixIcon: Icon(Icons.phone_outlined), counterText: ''),
                  validator: (value) => (value ?? '').trim().isEmpty
                      ? 'أدخل رقم الهاتف' : null,
                ),
                const SizedBox(height: 10),
                TextFormField(
                  controller: _creditLimit,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.allow(
                    RegExp(r'[0-9٠-٩۰-۹٬, ]'))],
                  decoration: const InputDecoration(
                    labelText: 'سقف الدين بالريال',
                    hintText: '50000',
                    prefixIcon: Icon(Icons.account_balance_wallet_outlined),
                  ),
                  validator: (value) {
                    final n = MoneyFormat.parseWholeRiyals(value ?? '');
                    if (n == null) return 'أدخل مبلغاً صحيحاً (حتى 12 رقماً)';
                    if (n < 0) return 'السقف لا يمكن أن يكون سالباً';
                    return null;
                  },
                ),
                if (_failure != null) ...[
                  const SizedBox(height: 12),
                  Text(_failure!, style: TextStyle(
                    color: Theme.of(context).colorScheme.error)),
                ],
              ],
            ),
          ),
        ),
      ),
      actions: [
        TextButton(onPressed: _busy ? null : () => Navigator.pop(context),
          child: const Text('إلغاء')),
        FilledButton(onPressed: _busy ? null : _submit,
          child: Text(_busy ? 'جارٍ الحفظ...' : 'إضافة الزبون')),
      ],
    );
  }
}
