import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/debt_transaction.dart';
import '../services/ledger_service.dart';
import '../services/notification_service.dart';
import '../theme/app_theme.dart';
import '../utils/money_format.dart';
import 'quick_transaction_dialog.dart';
import 'receipt_preview_dialog.dart';

class CustomerDetailsScreen extends StatefulWidget {
  const CustomerDetailsScreen({
    super.key,
    required this.customerId,
    required this.shopName,
    this.shopPhone,
    this.shopAddress,
    this.ledgerService,
    this.notificationService,
  });

  final int customerId;
  final String shopName;
  final String? shopPhone;
  final String? shopAddress;
  final LedgerService? ledgerService;
  final NotificationService? notificationService;

  @override
  State<CustomerDetailsScreen> createState() => _CustomerDetailsScreenState();
}

class _CustomerDetailsScreenState extends State<CustomerDetailsScreen> {
  late final LedgerService _ledger = widget.ledgerService ?? LedgerService();
  late final NotificationService _notifications =
      widget.notificationService ?? NotificationService(ledger: _ledger);
  CustomerStatement? _statement;
  bool _loading = true;
  bool _actionBusy = false;
  String? _error;
  int _loadVersion = 0;

  @override
  void initState() {
    super.initState();
    _reload();
  }

  @override
  void dispose() {
    _loadVersion++;
    super.dispose();
  }

  Future<void> _reload() async {
    final request = ++_loadVersion;
    try {
      final statement = await _ledger.getStatement(widget.customerId);
      if (!mounted || request != _loadVersion) return;
      setState(() {
        _loading = false;
        _error = null;
        _statement = statement;
      });
    } catch (error) {
      if (!mounted || request != _loadVersion) return;
      setState(() {
        _loading = false;
        _error = 'تعذر تحميل كشف الحساب أو فشل التحقق من سلامته.';
      });
    }
  }

  void _message(String value) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(value)));
  }

  Future<void> _quick() async {
    final statement = _statement;
    if (statement == null) return;
    final result = await showDialog<QuickTransactionResult>(
      context: context,
      builder: (_) => QuickTransactionDialog(
        customer: statement.customer,
        shopName: widget.shopName,
        ledgerService: _ledger,
        notificationService: _notifications,
      ),
    );
    if (result == null || !mounted) return;
    _message(result.smsError == null
        ? 'تم حفظ العملية بنجاح.'
        : 'حُفظ الدين ولكن تعذر إرسال SMS.');
    await _reload();
  }

  Future<void> _shareStatement() async {
    if (_actionBusy) return;
    setState(() => _actionBusy = true);
    try {
      await _notifications.openWhatsAppStatement(
        customerId: widget.customerId,
        shopName: widget.shopName,
        maxEntries: 100,
      );
    } catch (error) {
      if (mounted) _message('لم يمكن فتح واتساب. تحقق من رقم الزبون وتوفر التطبيق.');
    } finally {
      if (mounted) setState(() => _actionBusy = false);
    }
  }

  Future<void> _previewReceipt(LedgerEntry entry) async {
    if (_actionBusy) return;
    setState(() => _actionBusy = true);
    try {
      final receipt = await _ledger.createSignedReceipt(
        customerId: widget.customerId,
        transactionId: entry.transaction.id!,
        shopName: widget.shopName,
        shopPhone: widget.shopPhone,
        shopAddress: widget.shopAddress,
      );
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (_) => ReceiptPreviewDialog(receipt: receipt),
      );
    } catch (error) {
      if (mounted) _message('تعذر إعداد الفاتورة. تأكد من سلامة السجل ومفتاح التوقيع.');
    } finally {
      if (mounted) setState(() => _actionBusy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final statement = _statement;
    return Scaffold(
      appBar: AppBar(
        title: Text(statement?.customer.name ?? 'كشف حساب الزبون'),
        actions: [
          IconButton(
            tooltip: 'عملية سريعة',
            onPressed: statement == null || _actionBusy ? null : _quick,
            icon: const Icon(Icons.add_circle_outline),
          ),
          IconButton(
            tooltip: 'تحديث',
            onPressed: _reload,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: _error != null && statement == null
          ? Center(child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.warning_amber, color: Theme.of(context).colorScheme.error,
                    size: 46),
                const SizedBox(height: 10),
                Text(_error!, textAlign: TextAlign.center),
                TextButton(onPressed: _reload, child: const Text('إعادة المحاولة')),
              ],
            ))
          : statement == null
              ? const Center(child: CircularProgressIndicator())
              : RefreshIndicator(
                  onRefresh: _reload,
                  child: ListView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
                    itemCount: statement.entries.length + 1,
                    itemBuilder: (context, index) {
                      if (index == 0) {
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: [
                            _AccountSummary(statement: statement),
                            const SizedBox(height: 20),
                            Row(children: [
                              Text('سجل الحركات المالية',
                                style: Theme.of(context).textTheme.titleLarge?.copyWith(
                                  fontWeight: FontWeight.w800)),
                              const Spacer(),
                              Text('${statement.entries.length} حركة',
                                  style: Theme.of(context).textTheme.bodySmall),
                            ]),
                            const SizedBox(height: 8),
                            if (statement.entries.isEmpty)
                              const Padding(
                                padding: EdgeInsets.symmetric(vertical: 35),
                                child: Center(child: Text('لا توجد عمليات مسجلة حتى الآن.')),
                              ),
                          ],
                        );
                      }
                      final entry = statement.entries[index - 1];
                      return _MovementCard(
                        key: ValueKey(entry.transaction.id),
                        entry: entry,
                        onTap: () => _previewReceipt(entry),
                      );
                    },
                  ),
                ),
      bottomNavigationBar: statement == null
          ? null
          : SafeArea(
              top: false,
              child: Container(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 12),
                color: Theme.of(context).colorScheme.surface,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    FilledButton.icon(
                      onPressed: _actionBusy ? null : _shareStatement,
                      icon: const Icon(Icons.chat_bubble_outline),
                      label: const Text('مشاركة كشف الحساب عبر الواتساب'),
                    ),
                    const SizedBox(height: 7),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: _actionBusy || statement.entries.isEmpty
                            ? null : () => _previewReceipt(statement.entries.first),
                        icon: const Icon(Icons.print_outlined),
                        label: const Text('طباعة/تصدير الفاتورة الأخيرة'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }
}

class _AccountSummary extends StatelessWidget {
  const _AccountSummary({required this.statement});
  final CustomerStatement statement;

  @override
  Widget build(BuildContext context) {
    final customer = statement.customer;
    final atCap = customer.currentBalance > 0 &&
        customer.currentBalance >= customer.creditLimit;
    final accent = atCap ? AppTheme.negative : AppTheme.positive;
    final progress = customer.creditLimit <= 0
        ? 0.0 : (customer.currentBalance / customer.creditLimit).clamp(0.0, 1.0).toDouble();
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(19),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text('الرصيد الحالي المستحق',
                style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 7),
            Text(MoneyFormat.riyals(statement.remainingBalance),
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  fontWeight: FontWeight.w900, color: accent)),
            const SizedBox(height: 18),
            Row(children: [
              Expanded(child: _AccountNumber(title: 'إجمالي الديون',
                  value: statement.totalDebts, color: AppTheme.negative)),
              Expanded(child: _AccountNumber(title: 'إجمالي السداد',
                  value: statement.totalPayments, color: AppTheme.positive)),
            ]),
            const SizedBox(height: 15),
            LinearProgressIndicator(value: progress, minHeight: 6,
                color: accent, borderRadius: BorderRadius.circular(8)),
            const SizedBox(height: 9),
            Row(children: [
              Expanded(child: Text('سقف الدين: ${MoneyFormat.riyals(customer.creditLimit)}',
                  style: Theme.of(context).textTheme.bodySmall)),
              Text('متاح: ${MoneyFormat.riyals(statement.availableCredit)}',
                  style: Theme.of(context).textTheme.bodySmall),
            ]),
            const SizedBox(height: 8),
            Text('الهاتف: ${customer.phone}',
                style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}

class _AccountNumber extends StatelessWidget {
  const _AccountNumber({required this.title, required this.value, required this.color});
  final String title;
  final int value;
  final Color color;
  @override
  Widget build(BuildContext context) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title, style: Theme.of(context).textTheme.bodySmall),
      const SizedBox(height: 4),
      FittedBox(fit: BoxFit.scaleDown, child: Text(MoneyFormat.riyals(value),
          style: TextStyle(color: color, fontSize: 16, fontWeight: FontWeight.bold))),
    ],
  );
}

class _MovementCard extends StatelessWidget {
  const _MovementCard({super.key, required this.entry, required this.onTap});
  final LedgerEntry entry;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final movement = entry.transaction;
    final debt = movement.type == DebtTransactionType.debt;
    final accent = debt ? AppTheme.negative : AppTheme.positive;
    final date = DateFormat('yyyy/MM/dd - HH:mm', 'ar')
        .format(movement.createdAt.toLocal());
    return Card(
      margin: const EdgeInsets.only(bottom: 9),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Row(children: [
            CircleAvatar(
              radius: 23,
              backgroundColor: accent.withValues(alpha: 0.12),
              foregroundColor: accent,
              child: Icon(debt ? Icons.shopping_basket_outlined : Icons.payments_outlined),
            ),
            const SizedBox(width: 11),
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(debt ? 'دين #${movement.id}' : 'سداد #${movement.id}',
                    style: const TextStyle(fontWeight: FontWeight.bold)),
                if (debt)
                  Text(movement.purchases, maxLines: 2, overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall),
                Text(date, style: Theme.of(context).textTheme.bodySmall),
                Text('المتبقي حينها: ${MoneyFormat.riyals(entry.balanceAfter)}',
                    style: Theme.of(context).textTheme.bodySmall),
              ],
            )),
            const SizedBox(width: 6),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Text('${debt ? '+' : '−'}${MoneyFormat.amount(movement.amount)}',
                  style: TextStyle(color: accent, fontWeight: FontWeight.w900,
                    fontSize: 17)),
              const Text('ريال', style: TextStyle(fontSize: 11)),
              const SizedBox(height: 4),
              const Icon(Icons.chevron_left, size: 20),
            ]),
          ]),
        ),
      ),
    );
  }
}
