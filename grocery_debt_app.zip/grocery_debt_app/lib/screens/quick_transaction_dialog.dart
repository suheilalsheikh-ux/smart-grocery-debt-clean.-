import 'package:flutter/material.dart';

import '../models/customer.dart';
import '../models/debt_transaction.dart';
import '../services/ledger_service.dart';
import '../services/notification_service.dart';
import '../utils/money_format.dart';

/// A completed accounting entry. An SMS failure is nonfatal: the debt is saved.
class QuickTransactionResult {
  final LedgerOperationResult saved;
  final Object? smsError;

  const QuickTransactionResult(this.saved, {this.smsError});
}

class QuickTransactionDialog extends StatefulWidget {
  const QuickTransactionDialog({
    super.key,
    required this.customer,
    required this.shopName,
    this.ledgerService,
    this.notificationService,
  });

  final Customer customer;
  final String shopName;
  final LedgerService? ledgerService;
  final NotificationService? notificationService;

  @override
  State<QuickTransactionDialog> createState() => _QuickTransactionDialogState();
}

class _QuickTransactionDialogState extends State<QuickTransactionDialog> {
  final TextEditingController _items = TextEditingController();
  DebtTransactionType _type = DebtTransactionType.debt;
  String _digits = '';
  bool _sendSms = false;
  bool _saving = false;
  String? _error;

  late final LedgerService _ledger = widget.ledgerService ?? LedgerService();
  late final NotificationService _notifications =
      widget.notificationService ?? NotificationService(ledger: _ledger);

  @override
  void dispose() {
    _items.dispose();
    super.dispose();
  }

  void _press(String key) {
    if (_saving) return;
    setState(() {
      _error = null;
      if (key == 'C') {
        _digits = '';
      } else if (key == 'DEL') {
        if (_digits.isNotEmpty) _digits = _digits.substring(0, _digits.length - 1);
      } else if (_digits.length < 12) {
        final value = _digits == '0' ? key : '$_digits$key';
        _digits = value == '0' ? '' : value;
      }
    });
  }

  Future<void> _save() async {
    if (_saving) return;
    final id = widget.customer.id;
    final amount = int.tryParse(_digits);
    if (id == null || amount == null || amount <= 0) {
      setState(() => _error = 'أدخل مبلغاً صحيحاً أكبر من صفر.');
      return;
    }
    if (_type == DebtTransactionType.debt && _items.text.trim().isEmpty) {
      setState(() => _error = 'اكتب الأصناف، مثال: زبادي + خبز.');
      return;
    }
    setState(() {
      _saving = true;
      _error = null;
    });
    try {
      late final QuickTransactionResult result;
      if (_type == DebtTransactionType.debt) {
        final outcome = await _notifications.recordDebtAndNotify(
          customerId: id,
          amount: amount,
          items: _items.text.trim(),
          shopName: widget.shopName,
          smsEnabledByShopkeeper: _sendSms,
        );
        result = QuickTransactionResult(outcome.savedDebt, smsError: outcome.smsError);
      } else {
        final saved = await _ledger.registerPayment(customerId: id, amount: amount);
        result = QuickTransactionResult(saved);
      }
      if (!mounted) return;
      Navigator.of(context).pop(result);
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = _readableError(error));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  String _readableError(Object error) {
    if (error is StateError) return error.message;
    if (error is ArgumentError) return error.message?.toString() ?? 'مدخل غير صحيح.';
    return 'تعذر حفظ العملية. تحقق من البيانات وحاول مجدداً.';
  }

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final available = widget.customer.creditLimit - widget.customer.currentBalance;
    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 430),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(18),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  CircleAvatar(
                    backgroundColor: scheme.primaryContainer,
                    child: const Icon(Icons.person_outline),
                  ),
                  const SizedBox(width: 9),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.customer.name,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                              fontWeight: FontWeight.bold,
                            )),
                        Text('المستحق ${MoneyFormat.riyals(widget.customer.currentBalance)}',
                            style: Theme.of(context).textTheme.bodySmall),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: _saving ? null : () => Navigator.pop(context),
                    icon: const Icon(Icons.close),
                    tooltip: 'إغلاق',
                  ),
                ],
              ),
              const SizedBox(height: 16),
              SegmentedButton<DebtTransactionType>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(
                    value: DebtTransactionType.debt,
                    icon: Icon(Icons.add_shopping_cart_outlined),
                    label: Text('دين جديد'),
                  ),
                  ButtonSegment(
                    value: DebtTransactionType.payment,
                    icon: Icon(Icons.payments_outlined),
                    label: Text('تسجيل سداد'),
                  ),
                ],
                selected: {_type},
                onSelectionChanged: _saving ? null : (values) {
                  setState(() {
                    _type = values.first;
                    _error = null;
                    _sendSms = false;
                  });
                },
              ),
              const SizedBox(height: 14),
              Text(
                _digits.isEmpty ? '0' : MoneyFormat.amount(int.parse(_digits)),
                textAlign: TextAlign.center,
                textDirection: TextDirection.ltr,
                style: Theme.of(context).textTheme.displaySmall?.copyWith(
                  fontWeight: FontWeight.w800,
                  color: scheme.primary,
                ),
              ),
              const Text('ريال يمني', textAlign: TextAlign.center),
              const SizedBox(height: 10),
              for (final row in const [
                ['1', '2', '3'],
                ['4', '5', '6'],
                ['7', '8', '9'],
                ['C', '0', 'DEL'],
              ])
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(
                    children: [
                      for (final key in row)
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 3),
                            child: SizedBox(
                              height: 58,
                              child: FilledButton.tonal(
                                onPressed: _saving ? null : () => _press(key),
                                style: FilledButton.styleFrom(
                                  padding: EdgeInsets.zero,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(14),
                                  ),
                                ),
                                child: key == 'DEL'
                                    ? const Icon(Icons.backspace_outlined)
                                    : key == 'C'
                                        ? const Text('مسح', style: TextStyle(fontSize: 17))
                                        : Text(key, style: const TextStyle(
                                            fontSize: 24, fontWeight: FontWeight.bold)),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              if (_type == DebtTransactionType.debt) ...[
                const SizedBox(height: 6),
                TextField(
                  controller: _items,
                  enabled: !_saving,
                  maxLines: 1,
                  textInputAction: TextInputAction.done,
                  decoration: const InputDecoration(
                    labelText: 'الأصناف المشتراة',
                    hintText: 'زبادي + خبز',
                    prefixIcon: Icon(Icons.shopping_basket_outlined),
                  ),
                ),
                const SizedBox(height: 4),
                Text('المتاح ضمن السقف: ${MoneyFormat.riyals(available < 0 ? 0 : available)}',
                    style: Theme.of(context).textTheme.bodySmall),
                SwitchListTile.adaptive(
                  contentPadding: EdgeInsets.zero,
                  title: const Text('إرسال SMS تلقائياً'),
                  subtitle: const Text('يحتاج صلاحية أندرويد وموافقة صاحب البقالة.'),
                  value: _sendSms,
                  onChanged: _saving ? null : (value) => setState(() => _sendSms = value),
                ),
              ],
              if (_error != null) ...[
                const SizedBox(height: 6),
                Text(_error!, style: TextStyle(color: scheme.error)),
              ],
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: _saving ? null : _save,
                icon: _saving
                    ? const SizedBox(width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2))
                    : const Icon(Icons.check_circle_outline),
                label: Text(_saving ? 'جارٍ الحفظ...' : 'حفظ العملية'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
