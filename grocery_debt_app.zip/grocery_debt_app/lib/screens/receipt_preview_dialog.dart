import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import '../services/ledger_service.dart';
import '../services/receipt_export_service.dart';
import '../widgets/receipt_card.dart';

/// A print/export preview for ONE immutable, signed debt or payment entry.
class ReceiptPreviewDialog extends StatefulWidget {
  const ReceiptPreviewDialog({super.key, required this.receipt});
  final SignedLedgerReceipt receipt;

  @override
  State<ReceiptPreviewDialog> createState() => _ReceiptPreviewDialogState();
}

class _ReceiptPreviewDialogState extends State<ReceiptPreviewDialog> {
  final _boundaryKey = GlobalKey();
  final _exporter = const ReceiptExportService();
  Uint8List? _cachedPdf;
  bool _busy = false;
  String? _error;

  String get _fileName =>
      'grocery_receipt_${widget.receipt.entry.transaction.id}.pdf';

  Future<Uint8List> _pdf() async {
    final cached = _cachedPdf;
    if (cached != null) return cached;
    // A frame is scheduled when the loading state changes; capture after paint.
    await WidgetsBinding.instance.endOfFrame;
    final render = _boundaryKey.currentContext?.findRenderObject();
    if (render is! RenderRepaintBoundary) {
      throw StateError('لم يكتمل رسم الإيصال بعد.');
    }
    return _cachedPdf = await _exporter.createPdfFromBoundary(render);
  }

  Future<void> _run(Future<void> Function(Uint8List pdf) action) async {
    if (_busy) return;
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await action(await _pdf());
    } catch (error) {
      if (!mounted) return;
      setState(() => _error = 'تعذرت الطباعة أو مشاركة PDF. تحقق من التطبيقات المتاحة.');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    return Dialog(
      insetPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 14),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxWidth: 440, maxHeight: size.height * 0.9),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Row(children: [
                const Expanded(child: Text('معاينة الفاتورة الرقمية',
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18))),
                IconButton(
                  onPressed: _busy ? null : () => Navigator.of(context).pop(),
                  icon: const Icon(Icons.close),
                  tooltip: 'إغلاق',
                ),
              ]),
              const SizedBox(height: 8),
              Flexible(
                child: SingleChildScrollView(
                  child: Center(
                    child: FittedBox(
                      fit: BoxFit.scaleDown,
                      child: RepaintBoundary(
                        key: _boundaryKey,
                        child: ReceiptCard(receipt: widget.receipt),
                      ),
                    ),
                  ),
                ),
              ),
              if (_error != null)
                Text(_error!, style: TextStyle(
                  color: Theme.of(context).colorScheme.error)),
              const SizedBox(height: 10),
              Row(children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: _busy ? null : () => _run((pdf) =>
                      _exporter.sharePdf(pdf, filename: _fileName)),
                    icon: const Icon(Icons.ios_share_outlined),
                    label: const Text('تصدير PDF'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: _busy ? null : () => _run((pdf) =>
                      _exporter.printReceipt(pdf, filename: _fileName)),
                    icon: const Icon(Icons.print_outlined),
                    label: const Text('طباعة'),
                  ),
                ),
              ]),
              if (_busy) const LinearProgressIndicator(),
            ],
          ),
        ),
      ),
    );
  }
}
