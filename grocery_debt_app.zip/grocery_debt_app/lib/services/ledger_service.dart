import '../models/customer.dart';
import '../models/debt_transaction.dart';
import 'database_helper.dart';
import 'receipt_signing_service.dart';

/// One transaction and the balance at the moment it was recorded.
class LedgerEntry {
  final DebtTransaction transaction;
  final int balanceAfter;

  const LedgerEntry({
    required this.transaction,
    required this.balanceAfter,
  });
}

/// An immutable account statement with its latest balance and movements.
class CustomerStatement {
  final Customer customer;
  final List<LedgerEntry> entries;
  final int totalDebts;
  final int totalPayments;

  const CustomerStatement({
    required this.customer,
    required this.entries,
    required this.totalDebts,
    required this.totalPayments,
  });

  int get remainingBalance => customer.currentBalance;
  int get availableCredit => customer.creditLimit - remainingBalance;
}

/// A durable DB record and a corresponding balance snapshot.
class LedgerOperationResult {
  final Customer customer;
  final LedgerEntry entry;

  const LedgerOperationResult({
    required this.customer,
    required this.entry,
  });
}

/// A receipt that can be rendered on screen or printed.
/// The `qrPayload` is signed with Ed25519 (not just SHA-256 hashed).
class SignedLedgerReceipt {
  final String shopName;
  final String? shopPhone;
  final String? shopAddress;
  final String currencyCode;
  final String currencySymbol;
  final int unitsPerMajor;
  final Customer customer;
  final LedgerEntry entry;
  final String qrPayload;
  final String signingPublicKey;
  final String signingKeyFingerprint;

  const SignedLedgerReceipt({
    required this.shopName,
    required this.shopPhone,
    required this.shopAddress,
    required this.currencyCode,
    required this.currencySymbol,
    required this.unitsPerMajor,
    required this.customer,
    required this.entry,
    required this.qrPayload,
    required this.signingPublicKey,
    required this.signingKeyFingerprint,
  });
}

/// Business rules for the offline debt ledger.
///
/// Do not update Customer.currentBalance directly: DatabaseHelper persists the
/// transaction, checks the limit, updates the balance using a SQLite trigger,
/// and verifies the SHA-256 hash chain in a single SQL transaction.
class LedgerService {
  LedgerService({
    DatabaseHelper? database,
    ReceiptSigningService? receiptSigner,
  })  : _database = database ?? DatabaseHelper.instance,
        _receiptSigner = receiptSigner ?? ReceiptSigningService.instance;

  final DatabaseHelper _database;
  final ReceiptSigningService _receiptSigner;

  /// Adds a debt atomically; rejects amounts exceeding the credit ceiling.
  Future<LedgerOperationResult> addDebt({
    required int customerId,
    required int amount,
    required String items,
  }) async {
    _validateIdsAndAmount(customerId, amount);
    final cleanItems = items.trim();
    if (cleanItems.isEmpty) {
      throw ArgumentError.value(items, 'items', 'تفاصيل الأصناف مطلوبة.');
    }

    // DatabaseHelper performs the limit check INSIDE its SQL transaction.
    final transaction = await _database.addDebt(
      customerId: customerId,
      amount: amount,
      purchases: cleanItems,
    );
    return _resultForNewTransaction(transaction);
  }

  /// Records payment as a permanent payment/receipt row in SQLite.
  /// A payment exceeding the outstanding balance is rejected.
  Future<LedgerOperationResult> registerPayment({
    required int customerId,
    required int amount,
  }) async {
    _validateIdsAndAmount(customerId, amount);

    final transaction = await _database.registerPayment(
      customerId: customerId,
      amount: amount,
    );
    return _resultForNewTransaction(transaction);
  }

  /// Returns newest-first movements by recorded UTC timestamp (ID tie-break).
  /// Each balanceAfter follows the ACTUAL insertion order (transaction ID).
  Future<CustomerStatement> getStatement(int customerId) async {
    if (customerId <= 0) {
      throw ArgumentError.value(customerId, 'customerId', 'معرف غير صالح.');
    }

    final snapshot = await _database.getVerifiedCustomerLedger(customerId);
    final customer = snapshot.customer;
    final rows = List<DebtTransaction>.of(snapshot.transactions);

    var runningBalance = 0;
    var totalDebts = 0;
    var totalPayments = 0;
    final movements = <LedgerEntry>[];

    for (final movement in rows) {
      if (movement.type == DebtTransactionType.debt) {
        totalDebts += movement.amount;
        runningBalance += movement.amount;
      } else {
        totalPayments += movement.amount;
        runningBalance -= movement.amount;
      }
      if (runningBalance < 0) {
        throw StateError('تم اكتشاف سداد يتجاوز الرصيد أثناء مراجعة السجل.');
      }
      movements.add(LedgerEntry(
        transaction: movement,
        balanceAfter: runningBalance,
      ));
    }

    if (runningBalance != customer.currentBalance) {
      throw StateError('الرصيد المخزن لا يطابق مجموع المعاملات.');
    }

    movements.sort((a, b) {
      final dateResult = b.transaction.createdAt.compareTo(
        a.transaction.createdAt,
      );
      if (dateResult != 0) return dateResult;
      return b.transaction.id!.compareTo(a.transaction.id!);
    });

    return CustomerStatement(
      customer: customer,
      entries: List<LedgerEntry>.unmodifiable(movements),
      totalDebts: totalDebts,
      totalPayments: totalPayments,
    );
  }

  /// Builds a signed receipt for any existing transaction of this customer.
  /// No network access is required. The transaction itself is already in DB.
  Future<SignedLedgerReceipt> createSignedReceipt({
    required int customerId,
    required int transactionId,
    required String shopName,
    String? shopPhone,
    String? shopAddress,
    String currencyCode = 'YER',
    String currencySymbol = 'ر.ي',
    int unitsPerMajor = 1,
  }) async {
    if (shopName.trim().isEmpty) {
      throw ArgumentError.value(shopName, 'shopName', 'اسم البقالة مطلوب.');
    }
    if (unitsPerMajor <= 0 || !_isPowerOfTen(unitsPerMajor)) {
      throw ArgumentError.value(
        unitsPerMajor,
        'unitsPerMajor',
        'يجب أن يكون 1 أو 10 أو 100 أو 1000 ...',
      );
    }
    if (currencyCode.trim().isEmpty) {
      throw ArgumentError.value(currencyCode, 'currencyCode', 'العملة مطلوبة.');
    }

    final statement = await getStatement(customerId);
    LedgerEntry? found;
    for (final entry in statement.entries) {
      if (entry.transaction.id == transactionId) {
        found = entry;
        break;
      }
    }
    if (found == null) {
      throw StateError('المعاملة غير موجودة في حساب هذا الزبون.');
    }

    final signed = await _receiptSigner.signReceipt(
      storeName: shopName.trim(),
      customerName: statement.customer.name,
      currencyCode: currencyCode.trim(),
      unitsPerMajor: unitsPerMajor,
      transaction: found.transaction,
      balanceAfter: found.balanceAfter,
    );

    return SignedLedgerReceipt(
      shopName: shopName.trim(),
      shopPhone: shopPhone?.trim(),
      shopAddress: shopAddress?.trim(),
      currencyCode: currencyCode.trim(),
      currencySymbol: currencySymbol,
      unitsPerMajor: unitsPerMajor,
      customer: statement.customer,
      entry: found,
      qrPayload: signed.qrPayload,
      signingPublicKey: signed.publicKeyBase64,
      signingKeyFingerprint: signed.publicKeyFingerprint,
    );
  }

  /// Convenience method: persist the payment first, then prepare its receipt.
  /// If signing fails, the committed payment remains in SQLite. Retry receipt
  /// creation with its transaction ID; never record the payment a second time.
  Future<SignedLedgerReceipt> registerPaymentWithReceipt({
    required int customerId,
    required int amount,
    required String shopName,
    String? shopPhone,
    String? shopAddress,
    String currencyCode = 'YER',
    String currencySymbol = 'ر.ي',
    int unitsPerMajor = 1,
  }) async {
    final result = await registerPayment(
      customerId: customerId,
      amount: amount,
    );
    return createSignedReceipt(
      customerId: customerId,
      transactionId: result.entry.transaction.id!,
      shopName: shopName,
      shopPhone: shopPhone,
      shopAddress: shopAddress,
      currencyCode: currencyCode,
      currencySymbol: currencySymbol,
      unitsPerMajor: unitsPerMajor,
    );
  }

  Future<SignedLedgerReceipt> addDebtWithReceipt({
    required int customerId,
    required int amount,
    required String items,
    required String shopName,
    String? shopPhone,
    String? shopAddress,
    String currencyCode = 'YER',
    String currencySymbol = 'ر.ي',
    int unitsPerMajor = 1,
  }) async {
    final result = await addDebt(
      customerId: customerId,
      amount: amount,
      items: items,
    );
    return createSignedReceipt(
      customerId: customerId,
      transactionId: result.entry.transaction.id!,
      shopName: shopName,
      shopPhone: shopPhone,
      shopAddress: shopAddress,
      currencyCode: currencyCode,
      currencySymbol: currencySymbol,
      unitsPerMajor: unitsPerMajor,
    );
  }

  Future<LedgerOperationResult> _resultForNewTransaction(
    DebtTransaction transaction,
  ) async {
    final statement = await getStatement(transaction.customerId);
    for (final entry in statement.entries) {
      if (entry.transaction.id == transaction.id) {
        return LedgerOperationResult(
          customer: statement.customer,
          entry: entry,
        );
      }
    }
    throw StateError('لم يمكن العثور على المعاملة بعد حفظها.');
  }

  static void _validateIdsAndAmount(int customerId, int amount) {
    if (customerId <= 0) {
      throw ArgumentError.value(customerId, 'customerId', 'معرف غير صالح.');
    }
    if (amount <= 0) {
      throw ArgumentError.value(amount, 'amount', 'المبلغ يجب أن يكون موجباً.');
    }
  }

  static bool _isPowerOfTen(int n) {
    var value = n;
    while (value > 1 && value % 10 == 0) {
      value ~/= 10;
    }
    return value == 1;
  }
}
