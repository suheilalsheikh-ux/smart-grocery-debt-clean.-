import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../models/customer.dart';
import '../models/debt_transaction.dart';
import 'database_helper.dart';
import 'ledger_service.dart';

/// A debt with at least one unpaid installment older than [overdueDays].
/// This project has no contractual due-date column: age is counted from
/// transaction creation. Payments are assigned oldest-debt-first (FIFO).
class OverdueDebt {
  final Customer customer;
  final int overdueAmount;
  final int totalOutstanding;
  final DateTime oldestUnpaidDebtAt;
  final int overdueDays;
  final int thresholdDays;

  const OverdueDebt({
    required this.customer,
    required this.overdueAmount,
    required this.totalOutstanding,
    required this.oldestUnpaidDebtAt,
    required this.overdueDays,
    required this.thresholdDays,
  });
}

/// Android reports that all message parts were submitted to the mobile modem.
/// It does NOT prove recipient delivery or reading.
class SmsSendResult {
  final int parts;
  final int subscriptionId;

  const SmsSendResult({
    required this.parts,
    required this.subscriptionId,
  });
}

/// One accounting action and its optional SMS outcome. Debt always remains
/// committed even if the carrier submission fails afterwards.
class DebtNotificationOutcome {
  final LedgerOperationResult savedDebt;
  final SmsSendResult? smsResult;
  final Object? smsError;

  const DebtNotificationOutcome({
    required this.savedDebt,
    this.smsResult,
    this.smsError,
  });

  bool get smsSubmitted => smsResult != null;
}

class NotificationService {
  NotificationService({
    DatabaseHelper? database,
    LedgerService? ledger,
    MethodChannel? smsChannel,
  })  : _database = database ?? DatabaseHelper.instance,
        _ledger = ledger ?? LedgerService(database: database),
        _smsChannel = smsChannel ??
            const MethodChannel('smart_grocery_debt/sms');

  final DatabaseHelper _database;
  final LedgerService _ledger;
  final MethodChannel _smsChannel;

  /// We use one rial as the default accounting unit, as in stages 1 and 2.
  static String money(int amount) => NumberFormat.decimalPattern('ar').format(amount);

  /// Accept Yemeni mobile numbers (7XXXXXXXX), optionally prefixed with
  /// 0, +967, 00967 or 967; never silently guess a different destination.
  static String normalizeYemeniMobile(String value) {
    var digits = value.trim().replaceAll(RegExp(r'[\s()\-]'), '');
    if (digits.startsWith('+')) digits = digits.substring(1);
    if (digits.startsWith('00')) digits = digits.substring(2);
    if (digits.startsWith('967')) digits = digits.substring(3);
    if (digits.length == 10 && digits.startsWith('0')) {
      digits = digits.substring(1);
    }
    if (!RegExp(r'^7[0-9]{8}$').hasMatch(digits)) {
      throw FormatException('رقم الهاتف اليمني غير صالح. مثال: 777123456');
    }
    return '+967$digits';
  }

  static String buildNewDebtSms({
    required String customerName,
    required int amount,
    required int balance,
    required String shopName,
  }) {
    if (customerName.trim().isEmpty || shopName.trim().isEmpty) {
      throw ArgumentError('اسم الزبون والبقالة مطلوبان.');
    }
    return 'أخي/أختي ${customerName.trim()}، تم تسجيل دين بمبلغ '
        '${money(amount)} ريال في ${shopName.trim()}. '
        'إجمالي حسابك الحالي هو ${money(balance)} ريال. شكراً لتعاملكم.';
  }

  /// One-call flow for the debt screen: persist exactly once, then notify.
  /// SMS errors are returned separately and never roll back/repeat the debt.
  Future<DebtNotificationOutcome> recordDebtAndNotify({
    required int customerId,
    required int amount,
    required String items,
    required String shopName,
    required bool smsEnabledByShopkeeper,
  }) async {
    final saved = await _ledger.addDebt(
      customerId: customerId,
      amount: amount,
      items: items,
    );
    if (!smsEnabledByShopkeeper) {
      return DebtNotificationOutcome(savedDebt: saved);
    }
    try {
      final result = await sendNewDebtSms(
        recordedDebt: saved,
        shopName: shopName,
        smsEnabledByShopkeeper: smsEnabledByShopkeeper,
      );
      return DebtNotificationOutcome(savedDebt: saved, smsResult: result);
    } catch (error) {
      return DebtNotificationOutcome(savedDebt: saved, smsError: error);
    }
  }

  /// Called ONLY after the debt has been committed to SQLite via LedgerService.
  /// The shopkeeper must enable SMS in settings and inform the customer.
  /// A failed SMS must never cause the app to add the same debt again.
  Future<SmsSendResult> sendNewDebtSms({
    required LedgerOperationResult recordedDebt,
    required String shopName,
    required bool smsEnabledByShopkeeper,
  }) async {
    if (!smsEnabledByShopkeeper) {
      throw StateError('الإرسال التلقائي غير مفعّل في إعدادات البقالة.');
    }
    if (recordedDebt.entry.transaction.type != DebtTransactionType.debt) {
      throw ArgumentError('هذا الإشعار مخصص لمعاملة دين محفوظة.');
    }
    final transaction = recordedDebt.entry.transaction;
    if (transaction.id == null || recordedDebt.customer.id != transaction.customerId) {
      throw StateError('بيانات المعاملة غير صالحة.');
    }

    // Obtain a verified, current snapshot. Do not send based on tampered data.
    final statement = await _ledger.getStatement(transaction.customerId);
    LedgerEntry? verifiedEntry;
    for (final entry in statement.entries) {
      if (entry.transaction.id == transaction.id) {
        verifiedEntry = entry;
        break;
      }
    }
    if (verifiedEntry == null ||
        verifiedEntry.transaction.recordHash != transaction.recordHash ||
        verifiedEntry.transaction.type != DebtTransactionType.debt) {
      throw StateError('لم يمكن التحقق من معاملة الدين المحفوظة.');
    }
    final body = buildNewDebtSms(
      customerName: statement.customer.name,
      amount: verifiedEntry.transaction.amount,
      balance: verifiedEntry.balanceAfter,
      shopName: shopName,
    );
    return sendDirectSms(phone: statement.customer.phone, message: body);
  }

  /// Sends directly from the device's DEFAULT SMS SIM using native SmsManager.
  /// Android SEND_SMS permission is requested by MainActivity on first use.
  /// Use only in a permitted distribution context and after user opt-in.
  Future<SmsSendResult> sendDirectSms({
    required String phone,
    required String message,
  }) async {
    if (message.trim().isEmpty) throw ArgumentError('نص الرسالة مطلوب.');
    final recipient = normalizeYemeniMobile(phone);
    final response = await _smsChannel.invokeMapMethod<String, dynamic>(
      'sendSms',
      <String, Object>{'phone': recipient, 'message': message},
    );
    if (response == null || response['submitted'] != true) {
      throw StateError('لم يؤكد أندرويد إرسال أجزاء الرسالة إلى الشبكة.');
    }
    return SmsSendResult(
      parts: response['parts'] as int,
      subscriptionId: response['subscriptionId'] as int,
    );
  }

  /// Google-Play-friendly alternative: the owner presses Send in the SMS app.
  /// No SEND_SMS permission or native bridge is needed for this method.
  Future<void> openSmsComposer({
    required String phone,
    required String message,
  }) async {
    final recipient = normalizeYemeniMobile(phone);
    final uri = Uri(
      scheme: 'sms',
      path: recipient,
      queryParameters: <String, String>{'body': message},
    );
    final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!opened) throw StateError('لم يمكن فتح تطبيق الرسائل.');
  }

  /// Opens WhatsApp with prefilled text, NOT an auto-sent WhatsApp message.
  /// WhatsApp generally needs a data connection for delivery.
  Future<void> openWhatsApp({
    required String phone,
    required String message,
  }) async {
    if (message.trim().isEmpty) throw ArgumentError('نص الرسالة مطلوب.');
    final number = normalizeYemeniMobile(phone).substring(1);
    final uri = Uri(
      scheme: 'whatsapp',
      host: 'send',
      queryParameters: <String, String>{
        'phone': number,
        'text': message,
      },
    );
    try {
      final opened = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!opened) throw StateError('تطبيق واتساب غير متاح على الجهاز.');
    } on PlatformException catch (error) {
      throw StateError('تعذّر فتح واتساب: ${error.message ?? error.code}');
    }
  }

  /// Produce the current statement as a concise WhatsApp-ready message.
  Future<String> buildStatementMessage({
    required int customerId,
    required String shopName,
    int maxEntries = 15,
  }) async {
    if (shopName.trim().isEmpty || maxEntries < 1) {
      throw ArgumentError('اسم البقالة وحد العرض مطلوبان.');
    }
    final statement = await _ledger.getStatement(customerId);
    return _formatStatement(statement, shopName: shopName, maxEntries: maxEntries);
  }

  String _formatStatement(
    CustomerStatement statement, {
    required String shopName,
    required int maxEntries,
  }) {
    final entries = statement.entries.take(maxEntries).toList(growable: false);
    final buffer = StringBuffer()
      ..writeln('🧾 كشف حساب — ${shopName.trim()}')
      ..writeln('الزبون: ${statement.customer.name}')
      ..writeln('إجمالي الديون: ${money(statement.totalDebts)} ريال')
      ..writeln('إجمالي السداد: ${money(statement.totalPayments)} ريال')
      ..writeln('المتبقي: ${money(statement.remainingBalance)} ريال')
      ..writeln('--------------------');
    for (final entry in entries) {
      final transaction = entry.transaction;
      final type = transaction.type == DebtTransactionType.debt ? 'دين' : 'سداد';
      final date = DateFormat('yyyy-MM-dd HH:mm').format(transaction.createdAt.toLocal());
      buffer.writeln(
        '$date | $type ${money(transaction.amount)} ريال'
        '${transaction.purchases.isNotEmpty ? ' (${transaction.purchases})' : ''}',
      );
    }
    if (statement.entries.length > entries.length) {
      buffer.writeln('... عرض آخر ${entries.length} حركة من ${statement.entries.length}.');
    }
    buffer.write('شكراً لتعاملكم.');
    return buffer.toString();
  }

  Future<void> openWhatsAppStatement({
    required int customerId,
    required String shopName,
    int maxEntries = 15,
  }) async {
    if (shopName.trim().isEmpty || maxEntries < 1) {
      throw ArgumentError('اسم البقالة وحد العرض مطلوبان.');
    }
    final statement = await _ledger.getStatement(customerId);
    final message = _formatStatement(statement, shopName: shopName, maxEntries: maxEntries);
    await openWhatsApp(phone: statement.customer.phone, message: message);
  }

  Future<void> openWhatsAppReceipt({
    required SignedLedgerReceipt receipt,
  }) async {
    final transaction = receipt.entry.transaction;
    final kind = transaction.type == DebtTransactionType.debt ? 'فاتورة دين' : 'سند سداد';
    final message = '🧾 $kind — ${receipt.shopName}\n'
        'العميل: ${receipt.customer.name}\n'
        'رقم العملية: ${transaction.id}\n'
        'المبلغ: ${money(transaction.amount)} ريال\n'
        '${transaction.purchases.isNotEmpty ? 'الأصناف: ${transaction.purchases}\n' : ''}'
        'الرصيد بعد العملية: ${money(receipt.entry.balanceAfter)} ريال\n'
        'بصمة السجل SHA-256: ${transaction.recordHash}\n'
        'يمكن التحقق من توقيع النسخة المزودة برمز QR باستخدام المفتاح العام للبقالة.';
    await openWhatsApp(phone: receipt.customer.phone, message: message);
  }

  /// Returns overdue customers by age of the OLDEST UNPAID debt portion.
  /// Payment allocations: FIFO (oldest debt first). No due date is stored.
  /// `daysOverdue=30` means strictly more than 30 * 24 hours.
  Future<List<OverdueDebt>> getOverdueDebts({
    DateTime? asOf,
    int daysOverdue = 30,
  }) async {
    if (daysOverdue <= 0) throw ArgumentError('يجب تحديد عدد أيام موجب.');
    final reference = (asOf ?? DateTime.now()).toUtc();
    final customers = await _database.getAllCustomers();
    final overdue = <OverdueDebt>[];

    for (final customer in customers) {
      if (customer.currentBalance == 0) continue;
      final snapshot = await _database.getVerifiedCustomerLedger(customer.id!);
      final result = calculateOverdue(
        snapshot: snapshot,
        asOf: reference,
        daysOverdue: daysOverdue,
      );
      if (result != null) overdue.add(result);
    }

    overdue.sort((a, b) {
      final compare = a.oldestUnpaidDebtAt.compareTo(b.oldestUnpaidDebtAt);
      return compare != 0 ? compare : a.customer.name.compareTo(b.customer.name);
    });
    return List<OverdueDebt>.unmodifiable(overdue);
  }

  /// Pure calculation, suitable for unit tests without SQLite.
  static OverdueDebt? calculateOverdue({
    required VerifiedCustomerLedger snapshot,
    required DateTime asOf,
    int daysOverdue = 30,
  }) {
    if (daysOverdue <= 0) throw ArgumentError('يجب تحديد عدد أيام موجب.');
    final transactions = List<DebtTransaction>.of(snapshot.transactions)
      ..sort((a, b) => a.id!.compareTo(b.id!));
    final debts = transactions
        .where((transaction) => transaction.type == DebtTransactionType.debt)
        .toList(growable: false);
    var payments = 0;
    for (final transaction in transactions) {
      if (transaction.type == DebtTransactionType.payment) {
        payments += transaction.amount;
      }
    }

    final cutoff = asOf.toUtc().subtract(Duration(days: daysOverdue));
    var totalUnpaid = 0;
    var overdueAmount = 0;
    DateTime? oldest;

    for (final debt in debts) {
      final paidForThisDebt = payments < debt.amount ? payments : debt.amount;
      payments -= paidForThisDebt;
      final unpaid = debt.amount - paidForThisDebt;
      totalUnpaid += unpaid;
      if (unpaid > 0 && debt.createdAt.toUtc().isBefore(cutoff)) {
        overdueAmount += unpaid;
        oldest ??= debt.createdAt.toUtc();
      }
    }

    if (payments != 0 || totalUnpaid != snapshot.customer.currentBalance) {
      throw StateError('عدم تطابق توزيع السداد مع الرصيد المحفوظ.');
    }
    if (oldest == null || overdueAmount == 0) return null;

    final ageDays = asOf.toUtc().difference(oldest).inDays;
    return OverdueDebt(
      customer: snapshot.customer,
      overdueAmount: overdueAmount,
      totalOutstanding: snapshot.customer.currentBalance,
      oldestUnpaidDebtAt: oldest,
      overdueDays: ageDays,
      thresholdDays: daysOverdue,
    );
  }

  static String buildReminderMessage({
    required OverdueDebt overdue,
    required String shopName,
  }) {
    if (shopName.trim().isEmpty) throw ArgumentError('اسم البقالة مطلوب.');
    return 'مرحباً ${overdue.customer.name}، نذكّركم بلطف بأن مبلغ '
        '${money(overdue.overdueAmount)} ريال من حسابكم لدى ${shopName.trim()} '
        'مضى عليه أكثر من ${overdue.thresholdDays} يوماً. إجمالي الرصيد المتبقي '
        '${money(overdue.totalOutstanding)} ريال. '
        'إذا سبق السداد فتجاهلوا الرسالة، وشكراً لتعاملكم.';
  }

  Future<OverdueDebt> _refreshOverdue(OverdueDebt original) async {
    final latest = await _database.getVerifiedCustomerLedger(original.customer.id!);
    final refreshed = calculateOverdue(
      snapshot: latest,
      asOf: DateTime.now().toUtc(),
      daysOverdue: original.thresholdDays,
    );
    if (refreshed == null) {
      throw StateError('لم يعد الزبون متأخراً عن السداد.');
    }
    return refreshed;
  }

  Future<void> openWhatsAppReminder({
    required OverdueDebt overdue,
    required String shopName,
  }) async {
    final current = await _refreshOverdue(overdue);
    await openWhatsApp(
      phone: current.customer.phone,
      message: buildReminderMessage(overdue: current, shopName: shopName),
    );
  }

  Future<void> openSmsReminderComposer({
    required OverdueDebt overdue,
    required String shopName,
  }) async {
    final current = await _refreshOverdue(overdue);
    await openSmsComposer(
      phone: current.customer.phone,
      message: buildReminderMessage(overdue: current, shopName: shopName),
    );
  }

  /// Direct SMS is an explicit button action; never bulk-send silently.
  Future<SmsSendResult> sendSmsReminder({
    required OverdueDebt overdue,
    required String shopName,
    required bool smsEnabledByShopkeeper,
  }) async {
    if (!smsEnabledByShopkeeper) {
      throw StateError('يجب تفعيل إرسال SMS المباشر أولاً.');
    }
    // Recheck to avoid sending a stale reminder after a repayment.
    final current = await _refreshOverdue(overdue);
    return sendDirectSms(
      phone: current.customer.phone,
      message: buildReminderMessage(overdue: current, shopName: shopName),
    );
  }
}
