import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/rendering.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

/// Produces a fully offline PDF by embedding a Flutter-rendered receipt image.
/// This preserves Arabic shaping, colors and QR without downloading PDF fonts.
/// Call only from the explicit print/export action, not from build().
class ReceiptExportService {
  const ReceiptExportService();

  Future<Uint8List> createPdfFromBoundary(RenderRepaintBoundary boundary) async {
    final ui.Image image = await boundary.toImage(pixelRatio: 2.5);
    try {
      final data = await image.toByteData(format: ui.ImageByteFormat.png);
      if (data == null) throw StateError('تعذّر استخراج صورة الإيصال.');
      final pngBytes = data.buffer.asUint8List();
      final width = 80 * PdfPageFormat.mm;
      final height = width * (image.height / image.width);
      final document = pw.Document(compress: true);
      final page = PdfPageFormat(width, height, marginAll: 0);
      document.addPage(pw.Page(
        pageFormat: page,
        margin: pw.EdgeInsets.zero,
        build: (context) => pw.Image(
          pw.MemoryImage(pngBytes),
          width: width,
          height: height,
          fit: pw.BoxFit.fill,
        ),
      ));
      return document.save();
    } finally {
      image.dispose();
    }
  }

  Future<void> printReceipt(Uint8List pdf, {required String filename}) async {
    await Printing.layoutPdf(
      name: filename,
      onLayout: (format) async => pdf,
    );
  }

  Future<void> sharePdf(Uint8List pdf, {required String filename}) async {
    await Printing.sharePdf(bytes: pdf, filename: filename);
  }
}
