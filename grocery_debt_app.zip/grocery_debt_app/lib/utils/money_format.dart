import 'package:intl/intl.dart';

/// Financial values are stored as integer Yemeni rials, never doubles.
class MoneyFormat {
  MoneyFormat._();

  static final NumberFormat _number = NumberFormat.decimalPattern('ar');

  static String amount(int value) => _number.format(value);
  static String riyals(int value) => '${amount(value)} ريال';

  /// Accept Arabic-Indic, Eastern Arabic, and Western digits.
  static int? parseWholeRiyals(String input) {
    final normalized = input.trim().replaceAllMapped(
      RegExp(r'[٠-٩۰-۹]'),
      (m) {
        final code = m.group(0)!.runes.single;
        final digit = code >= 0x06F0 ? code - 0x06F0 : code - 0x0660;
        return digit.toString();
      },
    ).replaceAll(RegExp(r'[\s٬,]'), '');
    if (!RegExp(r'^\d{1,12}$').hasMatch(normalized)) return null;
    return int.tryParse(normalized);
  }
}
