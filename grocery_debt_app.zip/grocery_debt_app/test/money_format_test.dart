import 'package:flutter_test/flutter_test.dart';
import 'package:smart_grocery_debt/utils/money_format.dart';

void main() {
  test('Arabic and Western money amounts parse without floating point', () {
    expect(MoneyFormat.parseWholeRiyals('١٢٬٥٠٠'), 12500);
    expect(MoneyFormat.parseWholeRiyals('۱۲,۵۰۰'), 12500);
    expect(MoneyFormat.parseWholeRiyals('12,500'), 12500);
    expect(MoneyFormat.parseWholeRiyals('0'), 0);
    expect(MoneyFormat.parseWholeRiyals('12.5'), isNull);
    expect(MoneyFormat.parseWholeRiyals(''), isNull);
    expect(MoneyFormat.parseWholeRiyals('1234567890123'), isNull);
  });
}
