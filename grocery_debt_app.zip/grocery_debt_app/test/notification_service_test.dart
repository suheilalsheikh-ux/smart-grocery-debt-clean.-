import 'package:flutter_test/flutter_test.dart';
import 'package:smart_grocery_debt/models/customer.dart';
import 'package:smart_grocery_debt/models/debt_transaction.dart';
import 'package:smart_grocery_debt/services/database_helper.dart';
import 'package:smart_grocery_debt/services/notification_service.dart';

void main() {
  test('Yemen phone number normalization', () {
    expect(NotificationService.normalizeYemeniMobile('777123456'), '+967777123456');
    expect(NotificationService.normalizeYemeniMobile('0777123456'), '+967777123456');
    expect(NotificationService.normalizeYemeniMobile('+967 777 123456'), '+967777123456');
    expect(NotificationService.normalizeYemeniMobile('00967777123456'), '+967777123456');
    expect(
      () => NotificationService.normalizeYemeniMobile('12345'),
      throwsFormatException,
    );
  });

  test('SMS debt notification includes recorded amount and balance', () {
    final text = NotificationService.buildNewDebtSms(
      customerName: 'أحمد',
      amount: 1500,
      balance: 2500,
      shopName: 'بقالة البركة',
    );
    expect(text, contains('أحمد'));
    expect(text, contains('بقالة البركة'));
    expect(text, contains('إجمالي حسابك الحالي'));
  });

  test('FIFO ignores paid older debts and shows only old unpaid portion', () {
    const customer = Customer(
      id: 1,
      name: 'أحمد',
      phone: '777123456',
      creditLimit: 10000,
      currentBalance: 900,
    );
    final first = DebtTransaction.create(
      id: 1,
      customerId: 1,
      type: DebtTransactionType.debt,
      amount: 1200,
      purchases: 'مواد غذائية',
      createdAt: DateTime.utc(2026, 1, 1),
      previousHash: DebtTransaction.genesisHash,
    );
    final second = DebtTransaction.create(
      id: 2,
      customerId: 1,
      type: DebtTransactionType.debt,
      amount: 700,
      purchases: 'خبز',
      createdAt: DateTime.utc(2026, 2, 10),
      previousHash: first.recordHash,
    );
    final payment = DebtTransaction.create(
      id: 3,
      customerId: 1,
      type: DebtTransactionType.payment,
      amount: 1000,
      purchases: '',
      createdAt: DateTime.utc(2026, 2, 12),
      previousHash: second.recordHash,
    );
    final overdue = NotificationService.calculateOverdue(
      snapshot: VerifiedCustomerLedger(
        customer: customer,
        transactions: <DebtTransaction>[first, second, payment],
      ),
      asOf: DateTime.utc(2026, 3, 1),
      daysOverdue: 30,
    );
    expect(overdue, isNotNull);
    expect(overdue!.overdueAmount, 200);
    expect(overdue.totalOutstanding, 900);
    expect(overdue.thresholdDays, 30);
  });
}
