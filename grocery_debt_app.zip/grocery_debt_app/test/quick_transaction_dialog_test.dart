import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:smart_grocery_debt/models/customer.dart';
import 'package:smart_grocery_debt/screens/quick_transaction_dialog.dart';
import 'package:smart_grocery_debt/utils/money_format.dart';

void main() {
  testWidgets('numpad enters and deletes integer riyals', (tester) async {
    await tester.pumpWidget(const MaterialApp(
      home: Scaffold(
        body: QuickTransactionDialog(
          shopName: 'بقالتي',
          customer: Customer(id: 1, name: 'أحمد', phone: '777123456',
              creditLimit: 10000),
        ),
      ),
    ));
    await tester.tap(find.text('1').last);
    await tester.pump();
    await tester.tap(find.text('2').last);
    await tester.pump();
    expect(find.text(MoneyFormat.amount(12)), findsOneWidget);
    await tester.tap(find.byIcon(Icons.backspace_outlined));
    await tester.pump();
    expect(find.text(MoneyFormat.amount(1)), findsWidgets);
  });
}
