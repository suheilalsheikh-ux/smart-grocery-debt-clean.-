#!/usr/bin/env python3
"""Fill in Android's SDK-specific generated wrapper from local Flutter SDK.

Usage (from project root): python tools/prepare_android.py
"""
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
flutter = shutil.which('flutter')
if flutter is None:
    sys.exit('Flutter SDK غير موجود في PATH. ثبّت Flutter ثم أعد التنفيذ.')

with tempfile.TemporaryDirectory(prefix='grocery_flutter_platform_') as td:
    temp_project = Path(td) / 'smart_grocery_debt'
    subprocess.run([
        flutter, 'create', '--no-pub', '--platforms=android',
        '--project-name=smart_grocery_debt', '--org=com.example',
        str(temp_project),
    ], check=True)
    source = temp_project / 'android'
    # Preserve Flutter's authoritative version metadata from its generator.
    generated_metadata = temp_project / '.metadata'
    if generated_metadata.exists() and not (ROOT / '.metadata').exists():
        shutil.copy2(generated_metadata, ROOT / '.metadata')
    dest = ROOT / 'android'
    filled = []
    for generated in source.rglob('*'):
        if not generated.is_file():
            continue
        relative = generated.relative_to(source)
        target = dest / relative
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(generated, target)
            filled.append(relative.as_posix())
            if target.name == 'gradlew':
                target.chmod(target.stat().st_mode | 0o111)

    # Flutter generates android/local.properties from the installed SDK; do not
    # ship an absolute SDK path embedded in the ZIP.
    local_properties = dest / 'local.properties'
    if not local_properties.exists():
        sys.exit('لم يتم إنشاء android/local.properties؛ تحقق من Flutter SDK.')

print('تهيئة ملفات أندرويد اكتملت. ملفات جديدة:', ', '.join(filled) or 'لا يوجد')
print('الآن نفذ: flutter pub get && flutter analyze && flutter test && flutter build apk --release')
